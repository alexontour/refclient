/**
 */
package org.openhealthtools.mdht.uml.cda.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.openhealthtools.mdht.uml.cda.CDAPackage;
import org.openhealthtools.mdht.uml.cda.PharmSubjectOf4;
import org.openhealthtools.mdht.uml.cda.PharmSubstitutionPermission;

import org.openhealthtools.mdht.uml.hl7.rim.impl.InfrastructureRootImpl;

import org.openhealthtools.mdht.uml.hl7.vocab.ActClassRoot;
import org.openhealthtools.mdht.uml.hl7.vocab.ActMood;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pharm Subject Of4</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.openhealthtools.mdht.uml.cda.impl.PharmSubjectOf4Impl#getSubstitutionPermission <em>Substitution Permission</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class PharmSubjectOf4Impl extends InfrastructureRootImpl implements PharmSubjectOf4 {
	/**
	 * The cached value of the '{@link #getSubstitutionPermission() <em>Substitution Permission</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubstitutionPermission()
	 * @generated
	 * @ordered
	 */
	protected PharmSubstitutionPermission substitutionPermission;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PharmSubjectOf4Impl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CDAPackage.Literals.PHARM_SUBJECT_OF4;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PharmSubstitutionPermission getSubstitutionPermission() {
		return substitutionPermission;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSubstitutionPermission(PharmSubstitutionPermission newSubstitutionPermission, NotificationChain msgs) {
		PharmSubstitutionPermission oldSubstitutionPermission = substitutionPermission;
		substitutionPermission = newSubstitutionPermission;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CDAPackage.PHARM_SUBJECT_OF4__SUBSTITUTION_PERMISSION, oldSubstitutionPermission, newSubstitutionPermission);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSubstitutionPermission(PharmSubstitutionPermission newSubstitutionPermission) {
		if (newSubstitutionPermission != substitutionPermission) {
			NotificationChain msgs = null;
			if (substitutionPermission != null)
				msgs = ((InternalEObject)substitutionPermission).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CDAPackage.PHARM_SUBJECT_OF4__SUBSTITUTION_PERMISSION, null, msgs);
			if (newSubstitutionPermission != null)
				msgs = ((InternalEObject)newSubstitutionPermission).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CDAPackage.PHARM_SUBJECT_OF4__SUBSTITUTION_PERMISSION, null, msgs);
			msgs = basicSetSubstitutionPermission(newSubstitutionPermission, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CDAPackage.PHARM_SUBJECT_OF4__SUBSTITUTION_PERMISSION, newSubstitutionPermission, newSubstitutionPermission));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CDAPackage.PHARM_SUBJECT_OF4__SUBSTITUTION_PERMISSION:
				return basicSetSubstitutionPermission(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CDAPackage.PHARM_SUBJECT_OF4__SUBSTITUTION_PERMISSION:
				return getSubstitutionPermission();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CDAPackage.PHARM_SUBJECT_OF4__SUBSTITUTION_PERMISSION:
				setSubstitutionPermission((PharmSubstitutionPermission)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CDAPackage.PHARM_SUBJECT_OF4__SUBSTITUTION_PERMISSION:
				setSubstitutionPermission((PharmSubstitutionPermission)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CDAPackage.PHARM_SUBJECT_OF4__SUBSTITUTION_PERMISSION:
				return substitutionPermission != null;
		}
		return super.eIsSet(featureID);
	}

} //PharmSubjectOf4Impl
