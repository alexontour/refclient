/**
 */
package org.openhealthtools.mdht.uml.cda;

import org.openhealthtools.mdht.uml.hl7.datatypes.PQ;
import org.openhealthtools.mdht.uml.hl7.datatypes.QTY;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pharm QTY</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhealthtools.mdht.uml.cda.CDAPackage#getPharmQTY()
 * @model
 * @generated
 */
public interface PharmQTY extends PQ {
} // PharmQTY
