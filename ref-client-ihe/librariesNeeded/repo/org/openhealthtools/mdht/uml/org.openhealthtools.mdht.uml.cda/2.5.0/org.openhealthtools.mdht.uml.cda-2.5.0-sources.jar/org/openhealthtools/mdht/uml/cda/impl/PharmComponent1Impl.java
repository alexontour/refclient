/**
 */
package org.openhealthtools.mdht.uml.cda.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.openhealthtools.mdht.uml.cda.CDAPackage;
import org.openhealthtools.mdht.uml.cda.PharmComponent1;
import org.openhealthtools.mdht.uml.cda.PharmSubstitutionMade;

import org.openhealthtools.mdht.uml.hl7.rim.impl.InfrastructureRootImpl;

import org.openhealthtools.mdht.uml.hl7.vocab.ActClassRoot;
import org.openhealthtools.mdht.uml.hl7.vocab.ActMood;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pharm Component1</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.openhealthtools.mdht.uml.cda.impl.PharmComponent1Impl#getSubstitutionMade <em>Substitution Made</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class PharmComponent1Impl extends InfrastructureRootImpl implements PharmComponent1 {
	/**
	 * The cached value of the '{@link #getSubstitutionMade() <em>Substitution Made</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubstitutionMade()
	 * @generated
	 * @ordered
	 */
	protected PharmSubstitutionMade substitutionMade;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PharmComponent1Impl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CDAPackage.Literals.PHARM_COMPONENT1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PharmSubstitutionMade getSubstitutionMade() {
		return substitutionMade;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSubstitutionMade(PharmSubstitutionMade newSubstitutionMade, NotificationChain msgs) {
		PharmSubstitutionMade oldSubstitutionMade = substitutionMade;
		substitutionMade = newSubstitutionMade;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, CDAPackage.PHARM_COMPONENT1__SUBSTITUTION_MADE, oldSubstitutionMade, newSubstitutionMade);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSubstitutionMade(PharmSubstitutionMade newSubstitutionMade) {
		if (newSubstitutionMade != substitutionMade) {
			NotificationChain msgs = null;
			if (substitutionMade != null)
				msgs = ((InternalEObject)substitutionMade).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - CDAPackage.PHARM_COMPONENT1__SUBSTITUTION_MADE, null, msgs);
			if (newSubstitutionMade != null)
				msgs = ((InternalEObject)newSubstitutionMade).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - CDAPackage.PHARM_COMPONENT1__SUBSTITUTION_MADE, null, msgs);
			msgs = basicSetSubstitutionMade(newSubstitutionMade, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CDAPackage.PHARM_COMPONENT1__SUBSTITUTION_MADE, newSubstitutionMade, newSubstitutionMade));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CDAPackage.PHARM_COMPONENT1__SUBSTITUTION_MADE:
				return basicSetSubstitutionMade(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CDAPackage.PHARM_COMPONENT1__SUBSTITUTION_MADE:
				return getSubstitutionMade();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CDAPackage.PHARM_COMPONENT1__SUBSTITUTION_MADE:
				setSubstitutionMade((PharmSubstitutionMade)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CDAPackage.PHARM_COMPONENT1__SUBSTITUTION_MADE:
				setSubstitutionMade((PharmSubstitutionMade)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CDAPackage.PHARM_COMPONENT1__SUBSTITUTION_MADE:
				return substitutionMade != null;
		}
		return super.eIsSet(featureID);
	}

} //PharmComponent1Impl
