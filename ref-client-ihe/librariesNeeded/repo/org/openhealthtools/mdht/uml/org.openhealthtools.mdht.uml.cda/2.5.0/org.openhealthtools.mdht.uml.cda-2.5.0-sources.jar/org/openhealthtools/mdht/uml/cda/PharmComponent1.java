/**
 */
package org.openhealthtools.mdht.uml.cda;

import org.openhealthtools.mdht.uml.hl7.rim.InfrastructureRoot;

import org.openhealthtools.mdht.uml.hl7.vocab.ActClassRoot;
import org.openhealthtools.mdht.uml.hl7.vocab.ActMood;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pharm Component1</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openhealthtools.mdht.uml.cda.PharmComponent1#getSubstitutionMade <em>Substitution Made</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openhealthtools.mdht.uml.cda.CDAPackage#getPharmComponent1()
 * @model
 * @generated
 */
public interface PharmComponent1 extends InfrastructureRoot {
	/**
	 * Returns the value of the '<em><b>Substitution Made</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Substitution Made</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Substitution Made</em>' containment reference.
	 * @see #setSubstitutionMade(PharmSubstitutionMade)
	 * @see org.openhealthtools.mdht.uml.cda.CDAPackage#getPharmComponent1_SubstitutionMade()
	 * @model containment="true" ordered="false"
	 *        extendedMetaData="namespace='urn:ihe:pharm:medication'"
	 * @generated
	 */
	PharmSubstitutionMade getSubstitutionMade();

	/**
	 * Sets the value of the '{@link org.openhealthtools.mdht.uml.cda.PharmComponent1#getSubstitutionMade <em>Substitution Made</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Substitution Made</em>' containment reference.
	 * @see #getSubstitutionMade()
	 * @generated
	 */
	void setSubstitutionMade(PharmSubstitutionMade value);

} // PharmComponent1
