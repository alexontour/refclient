/**
 */
package org.openhealthtools.mdht.uml.cda;

import org.openhealthtools.mdht.uml.hl7.rim.InfrastructureRoot;

import org.openhealthtools.mdht.uml.hl7.vocab.ActClassRoot;
import org.openhealthtools.mdht.uml.hl7.vocab.ActMood;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pharm Subject Of4</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openhealthtools.mdht.uml.cda.PharmSubjectOf4#getSubstitutionPermission <em>Substitution Permission</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openhealthtools.mdht.uml.cda.CDAPackage#getPharmSubjectOf4()
 * @model
 * @generated
 */
public interface PharmSubjectOf4 extends InfrastructureRoot {
	/**
	 * Returns the value of the '<em><b>Substitution Permission</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Substitution Permission</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Substitution Permission</em>' containment reference.
	 * @see #setSubstitutionPermission(PharmSubstitutionPermission)
	 * @see org.openhealthtools.mdht.uml.cda.CDAPackage#getPharmSubjectOf4_SubstitutionPermission()
	 * @model containment="true" ordered="false"
	 *        extendedMetaData="namespace='urn:ihe:pharm:medication'"
	 * @generated
	 */
	PharmSubstitutionPermission getSubstitutionPermission();

	/**
	 * Sets the value of the '{@link org.openhealthtools.mdht.uml.cda.PharmSubjectOf4#getSubstitutionPermission <em>Substitution Permission</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Substitution Permission</em>' containment reference.
	 * @see #getSubstitutionPermission()
	 * @generated
	 */
	void setSubstitutionPermission(PharmSubstitutionPermission value);

} // PharmSubjectOf4
